const nonImportantIcon = "far fa-star";
const importantIcon = "fas fa-star";

var isImportant = false;
var isHidden = true;

function togglePanel() {
  console.log("is hidden");
  if (isHidden == true) {
    $("#panelForm").fadeOut();
    isHidden = false;
  } else {
    $("#panelForm").fadeIn();
    isHidden = true;
  }
}

function toggleImportant() {
  if (isImportant == true) {
    $("#importantIcon").removeClass(importantIcon).addClass(nonImportantIcon);
    isImportant = false;
  } else {
    $("#importantIcon").removeClass(nonImportantIcon).addClass(importantIcon);
    isImportant = true;
  }
}

function saveTask() {
  console.log("saving.....");
  /////////////////////////////////////////////
  //Read all vaules and save them to variables
  ////////////////////////////////////////////
  let title = $("#txtTitle").val();
  let duration = $("#txtDuration").val();
  let deadline = $("#selDeadline").val();
  let thelocation = $("#txtLocation").val();
  let status = $("#selStatus").val();

  console.log(title, duration, deadline, thelocation, status);

  let task = new Task(
    0,
    title,
    isImportant,
    duration,
    deadline,
    thelocation,
    status
  );
  console.log(task);
  console.log(JSON.stringify(task));

    $.ajax({
      url: "https://fsdiapi.azurewebsites.net/api/tasks/",
      type: "POST",
      data: JSON.stringify(task),
      contentType: "application/json",
      success: function(response){
        let savedTask = JSON.parse(response); //convert string into a js object
        displayTask(savedTask);
      },

      error: function(errorDetails){
        console.log("Error saving ",errorDetails);
      },
    });



}


function getStatusText(statusText){
  switch(statusText){

    case "0":
      {
        return "New";
      }

    case "1":
      {
        return "In Progress";
      }

    case "2":
      {
        return "Blocked";
      }

    case "3":
      {
        return "Completed";
      }

    case "4":
      {
        return "Removed";
      }

    default:
      {
        return "Missing";
      }
  }
}


function displayTask(task){

  let statusText = getStatusText(task.status);

    let syntax =

    `<div class = "task status-${task.status}">
        <h3>${task.title}</h3>
        <label>${task.location}<label>
        <div class="dates">
            <label>${task.duration}<label>
            <label>${task.deadline}<label>
            <label>${statusText}<label>
        </div>
    </div>`;


    $("#task-list").append(syntax);

}




function testRequest(){
  $.ajax({
    url: "https://fsdiapi.azurewebsites.net/",
    type: "GET",
    success: function(response){
      console.log(response);
    },

    error: function(errorDetails){
      console.log("Error on request ",errorDetails);
    },
  });
}


function fetchTasks(){
  $.ajax({
    url: "https://fsdiapi.azurewebsites.net/api/tasks",
    type: "GET",
    success: function(response){
      let tasks = JSON.parse(response); //array of tasks
     

      ///////////////////////////////////////////////////////
      // Using a FOR to scroll all arrays and display them.
      // And then just ckeck for just my id. If it is, display
      // it, if not, don´t.
      //////////////////////////////////////////////////////
      for(index=0;index<tasks.length;index++){
        let item = tasks[index];
        if(item.name == "Camarillo"){
        console.log(item);
        }
      }
      
    },

    error: function(errorDetails){
      console.log("Error saving ",errorDetails);
    },
  
});
}


  /////////////////////////////////////////
  //Delete all your tasks
  /////////////////////////////////////////


  /////////////////////////////////////////
  //Delete request to https://fsdiapi.azurewebsites.net/api/tasks/clear/YOURNAME
  /////////////////////////////////////////

  function clearAllTasks(){
    $.ajax({
      type: "DELETE",
      url: "https://fsdiapi.azurewebsites.net/api/tasks/clear/YOURNAME",
      success: function(){
        $("#task-list").html("");
      },
      //clear the data form the screen here

      error: function(errorDetails){
        console.error(errorDetails);
      },
    });
  }







function init() {
  //runTests();
  console.log("Task Manager");

  /////////////////////////////////////////
  //Load data
  /////////////////////////////////////////
  fetchTasks();



  /////////////////////////////////////////
  //Hook events
  /////////////////////////////////////////
  $("#importantIcon").click(toggleImportant);
  $("#btbShowHide").click(togglePanel);
  $("#btbSave").click(saveTask);
  $("#btbClear").click(clearAllTasks);
}

window.onload = init;
