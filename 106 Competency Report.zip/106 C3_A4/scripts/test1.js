

function Dog(name, age, color){
    this.name=name;
    this.age=age;
    this.color=color;
}

class Cat{
    constructor(name,age,color){
        this.name =name;
        this.age=age;
        this.color=age;
    }

    meow(){
        console.log("I´m meowing");
    }
}


function testObjects(){
    /////////////////////
    //object litera
    /////////////////////
    let dog1 = {
        name:"Fido",
        age: 4,
        color:"green",
    };
    console.log(dog1);


    ////////////////////////////////
    //Object Constructor
    ////////////////////////////////
    let dog3 = new Dog("fido",3,"green");

    console.log(dog3);
    console.log(dog3.name);


    ////////////////////////////////
    //Classes
    ////////////////////////////////
    let cat1 = new Cat("Dr meaw",1,"blue");
    console.log(cat1);
    console.log(cat1.name);
    cat1.meow();

}



function runTests(){
    console.log("---------TESTS-------------");

    testObjects();

}